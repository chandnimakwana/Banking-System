import java.sql.*; import java.io.IOException; 
import java.io.PrintWriter; 
import javax.servlet.ServletException; 
import javax.servlet.http.HttpServlet; 
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse; 
 
public class Register1 extends HttpServlet 
{     protected void service(HttpServletRequest request, HttpServletResponse response)throws ServletException, IOException 
    { 
        response.setContentType("text/html;charset=UTF-8"); 
        PrintWriter out = response.getWriter(); 
        String user=request.getParameter("txtName"); 
        String no=request.getParameter("txtNo"); 
         String amount=request.getParameter("txtAmount"); 
        String email=request.getParameter("txtEmail"); 
       String pass=request.getParameter("txtPass1");     
         try 
           { 
              Class.forName("com.mysql.jdbc.Driver"); 
              Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Banking","root","Star@123");           
              PreparedStatement pst=con.prepareStatement("insert into bank values(?,?,?,?,?)");            
              pst.setString(1,user);              
              pst.setString(2,no); 
               pst.setString(3,amount);              
               pst.setString(4,email);  
               pst.setString(5,pass);
               int row=pst.executeUpdate();             
               if(row==1) 
                 { 
                     out.println("Data inserted successfully"); 
                 }                  else 
                 { 
                     out.println("Data could not be inserted"); 
                 } 
            }                  catch(Exception e) 
                         {                        
                             out.println(e); 
                         } 
        } 
                  
} 
